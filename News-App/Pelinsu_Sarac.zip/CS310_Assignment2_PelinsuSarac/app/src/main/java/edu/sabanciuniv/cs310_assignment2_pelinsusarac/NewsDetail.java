package edu.sabanciuniv.cs310_assignment2_pelinsusarac;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.graphics.Bitmap;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.ImageView;
import android.widget.TextView;

public class NewsDetail extends AppCompatActivity {

    ImageView imgDetails;
    TextView txtTitle;
    TextView txtText;
    TextView txtDate;
    int id;

    Handler dataHandler = new Handler(new Handler.Callback() {
        @Override
        public boolean handleMessage(@NonNull Message msg) {

            News news = (News) msg.obj;

            txtTitle.setText(news.getTitle());
            txtText.setText(news.getText());


            String strDate = news.getDate();
            String needed = strDate.substring(0,10);
            String [] dateParts = needed.split("-");
            String newDate = dateParts[2] + "/" + dateParts[1] + "/" + dateParts[0];
            txtDate.setText(newDate);

            setTitle(news.getCategoryName());
            NewsRepository repo = new NewsRepository();
            repo.downloadImage(((NewsApplication)getApplication()).srv, imgHandler, news.getImagePath());

            return true;
        }
    });

    Handler imgHandler = new Handler(new Handler.Callback() {
        @Override
        public boolean handleMessage(@NonNull Message msg) {

            Bitmap img = (Bitmap) msg.obj;
            imgDetails.setImageBitmap(img);

            return true;
        }
    });

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_news_detail);

        id = getIntent().getIntExtra("id",1);

        imgDetails = findViewById(R.id.imageView2);
        txtTitle = findViewById(R.id.textTitle);
        txtText = findViewById(R.id.textText);
        txtDate = findViewById(R.id.textDate);


        NewsRepository repo = new NewsRepository();
        repo.getNewsById(((NewsApplication)getApplication()).srv, dataHandler, id);

        /*
        News n = new News();
        News news = n.returnData().get(id-1);

        txtTitle.setText(news.getTitle());
        txtText.setText(news.getText());


        String strDate = news.getDate();
        String needed = strDate.substring(0,10);
        String [] dateParts = needed.split("-");
        String newDate = dateParts[2] + "/" + dateParts[1] + "/" + dateParts[0];
        txtDate.setText(newDate);

        NewsRepository repo = new NewsRepository();
        repo.downloadImage(((NewsApplication)getApplication()).srv, imgHandler, news.getImagePath());
        setTitle(n.getCategoryName());
         */


        getSupportActionBar().setDisplayHomeAsUpEnabled(true);


    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.details_menu,menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {

        if(item.getItemId()==android.R.id.home){
            finish();
        }
        else if (item.getItemId()==R.id.mn_comments) {
            Intent i = new Intent(NewsDetail.this,CommentActivity.class);
            i.putExtra("id",id);
            startActivity(i);
        }

        return true;
    }
}