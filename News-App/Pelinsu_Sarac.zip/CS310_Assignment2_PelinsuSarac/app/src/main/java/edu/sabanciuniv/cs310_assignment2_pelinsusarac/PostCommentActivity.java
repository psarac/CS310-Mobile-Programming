package edu.sabanciuniv.cs310_assignment2_pelinsusarac;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.app.ProgressDialog;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import java.util.concurrent.ExecutorService;

public class PostCommentActivity extends AppCompatActivity {

    EditText txtName;
    EditText txtComment;
    Button btnPost;
    TextView alertMessage;
    private static final String message = "text, name, lastname cannot be null";
    ProgressDialog prgDialog;

    Handler postHandler = new Handler(new Handler.Callback() {
        @Override
        public boolean handleMessage(@NonNull Message msg) {
            prgDialog.dismiss();
            String retVal = msg.obj.toString();
            if (retVal.equals("SUCCESS")) {
                finish();
            }
            else {
                Toast.makeText(PostCommentActivity.this, retVal, Toast.LENGTH_SHORT).show();
            }

            return true;
        }


    });


    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_post_comment);

        int id = getIntent().getIntExtra("id",1);

        txtName = findViewById(R.id.editTxtName);
        txtComment = findViewById(R.id.editTxtComment);
        btnPost = findViewById(R.id.button);
        alertMessage = findViewById(R.id.textView3);
        alertMessage.setVisibility(View.INVISIBLE);

        btnPost.setOnClickListener(v->{
            String name = txtName.getText().toString();
            String comment = txtComment.getText().toString();
            if ((name.length() == 0) || (comment.length() == 0)) {
                alertMessage.setText(message);
                alertMessage.setVisibility(View.VISIBLE);
            }
            else {
                ExecutorService srv = (((NewsApplication)getApplication()).srv);
                CommentsRepository repo = new CommentsRepository();
                repo.postComment(srv, postHandler, name, comment, id);

                prgDialog = new ProgressDialog(PostCommentActivity.this);
                prgDialog.setMessage("Uploading the comment....");
                prgDialog.setTitle("Post Comment");

                prgDialog.show();
            }

        });

        setTitle("  Post Comment");
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {

        if(item.getItemId()==android.R.id.home){
            finish();
        }

        return true;
    }
}