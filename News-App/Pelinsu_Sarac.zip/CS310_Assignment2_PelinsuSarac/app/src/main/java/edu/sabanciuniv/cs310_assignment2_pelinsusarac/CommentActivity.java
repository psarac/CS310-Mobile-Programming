package edu.sabanciuniv.cs310_assignment2_pelinsusarac;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.ProgressBar;

import java.util.ArrayList;
import java.util.List;

public class CommentActivity extends AppCompatActivity {

    ProgressBar prg;
    RecyclerView recView;
    int id;


    Handler dataHandler = new Handler(new Handler.Callback() {
        @Override
        public boolean handleMessage(@NonNull Message msg) {
            List<Comment> data = (List<Comment>)msg.obj;
            CommentAdapter adp = new CommentAdapter(CommentActivity.this,data);
            recView.setAdapter(adp);
            recView.setVisibility(View.VISIBLE);
            prg.setVisibility(View.INVISIBLE);

            return true;
        }
    });


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_comment);

        id = getIntent().getIntExtra("id",1);

        prg = findViewById(R.id.progressBar);
        recView = findViewById(R.id.recyclerView);
        recView.setLayoutManager(new LinearLayoutManager(this));
        prg.setVisibility(View.VISIBLE);
        recView.setVisibility(View.INVISIBLE);

        //CommentsRepository repo = new CommentsRepository();
        //repo.getCommentsByNewsId(((NewsApplication)getApplication()).srv, dataHandler, id);



        /*
        List<Comment> data = new ArrayList<>();
        Comment cmt1 = new Comment(1,1,"test comment1", "test name");
        Comment cmt2 = new Comment(2,1,"test comment2", "test name");
        Comment cmt3 = new Comment(3,1,"test comment3", "test name");
        data.add(cmt1);
        data.add(cmt2);
        data.add(cmt3);

        CommentAdapter adp = new CommentAdapter(CommentActivity.this, data);
        recView.setAdapter(adp);

        recView.setVisibility(View.VISIBLE);
        prg.setVisibility(View.INVISIBLE);

         */

        setTitle("  Comments");
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
    }

    @Override
    protected void onStart() {
        super.onStart();

        CommentsRepository repo = new CommentsRepository();
        repo.getCommentsByNewsId(((NewsApplication)getApplication()).srv, dataHandler, id);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.comments_menu,menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {

        if(item.getItemId()==android.R.id.home){
            finish();
        }
        else if (item.getItemId() == R.id.mn_post) {
            Intent i = new Intent(CommentActivity.this,PostCommentActivity.class);
            i.putExtra("id",id);
            startActivity(i);
        }

        return true;
    }
}