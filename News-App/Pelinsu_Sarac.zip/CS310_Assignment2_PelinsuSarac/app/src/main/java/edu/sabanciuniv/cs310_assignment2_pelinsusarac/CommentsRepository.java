package edu.sabanciuniv.cs310_assignment2_pelinsusarac;

import android.os.Handler;
import android.os.Message;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedOutputStream;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.Executor;
import java.util.concurrent.ExecutorService;

public class CommentsRepository {

    public void getCommentsByNewsId (ExecutorService srv, Handler uiHandler, int id) {
        srv.execute(()-> {
            try {
                URL url = new URL("http://10.3.0.14:8080/newsapp/getcommentsbynewsid/" + String.valueOf(id));
                HttpURLConnection conn = (HttpURLConnection) url.openConnection();

                BufferedReader reader = new BufferedReader(new InputStreamReader(conn.getInputStream()));

                StringBuilder buffer = new StringBuilder();
                String line = "";

                while((line=reader.readLine())!=null){

                    buffer.append(line);
                }

                JSONObject incomingJSON = new JSONObject(buffer.toString());
                //ServiceMessage<JSONArray> incomingMsg = new ServiceMessage<JSONArray>(incomingJSON.getInt("serviceMessageCode"),
                //incomingJSON.getString("serviceMessageTest"), incomingJSON.getJSONArray("items"));
                JSONArray array = incomingJSON.getJSONArray("items");

                List<Comment> data = new ArrayList<>();

                for (int i = 0; i < array.length(); i++) {
                    JSONObject current = array.getJSONObject(i);
                    Comment cmt = new Comment(
                            current.getInt("id"),
                            current.getInt("news_id"),
                            current.getString("text"),
                            current.getString("name")

                    );
                    data.add(cmt);
                }

                Message msg = new Message();
                msg.obj = data;
                uiHandler.sendMessage(msg);

            } catch (MalformedURLException e) {
                e.printStackTrace();
            } catch (IOException e) {
                e.printStackTrace();
            } catch (JSONException e) {
                e.printStackTrace();
            }
        });
    }

    public void postComment (ExecutorService srv, Handler uiHandler, String name, String comment, int news_id) {
        srv.execute(()-> {

            URL url = null;
            try {
                url = new URL("http://10.3.0.14:8080/newsapp/savecomment");
                HttpURLConnection  conn = (HttpURLConnection) url.openConnection();


                conn.setDoInput(true);
                conn.setDoOutput(true);

                conn.setRequestMethod("POST");
                conn.setRequestProperty("Content-Type", "application/JSON");

                JSONObject outputData = new JSONObject();
                if (name != null) {outputData.put("name", name);}
                if (comment != null) {outputData.put("text", comment);}
                outputData.put("news_id", String.valueOf(news_id));

                BufferedOutputStream writer = new BufferedOutputStream(conn.getOutputStream());

                writer.write(outputData.toString().getBytes(StandardCharsets.UTF_8));
                writer.flush();

                BufferedReader reader = new BufferedReader(new InputStreamReader(conn.getInputStream()));

                StringBuilder buffer = new StringBuilder();

                String line = "";

                while((line=reader.readLine()) != null) {
                    buffer.append(line);
                }

                JSONObject retVal = new JSONObject(buffer.toString());
                String returnMessage = retVal.getString("serviceMessageText");

                conn.disconnect();

                Message msg = new Message();
                msg.obj = returnMessage;

                uiHandler.sendMessage(msg);

            } catch (MalformedURLException e) {
                e.printStackTrace();
            } catch (IOException e) {
                e.printStackTrace();
            } catch (JSONException e) {
                e.printStackTrace();
            }

        });
    }
}
