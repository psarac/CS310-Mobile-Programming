package edu.sabanciuniv.cs310_assignment2_pelinsusarac;

import java.util.ArrayList;
import java.util.List;

public class News {

    private int id;
    private String title, text, imagePath, categoryName, date;
    private List<News> data;

    public News(int id, String title, String text, String imagePath, String categoryName, String date) {
        this.id = id;
        this.title = title;
        this.text = text;
        this.imagePath = imagePath;
        this.categoryName = categoryName;
        this.date = date;
    }

    public News() {
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getText() {
        return text;
    }

    public void setText(String text) {
        this.text = text;
    }

    public String getImagePath() {
        return imagePath;
    }

    public void setImagePath(String imagePath) {
        this.imagePath = imagePath;
    }

    public String getCategoryName() {
        return categoryName;
    }

    public void setCategoryName(String categoryName) {
        this.categoryName = categoryName;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public List<News> returnData() {
        data = new ArrayList<>();
        News n1 = new News(1, "title1", "text1", "http://10.3.0.14:8080/newsapp/images/news10.jpg", "category1", "2022-12-14T21:00:00.000+00:00");
        News n2 = new News(2, "title2", "text1", "http://10.3.0.14:8080/newsapp/images/news10.jpg", "category1", "2022-12-14T21:00:00.000+00:00");
        News n3 = new News(3, "title3", "text1", "http://10.3.0.14:8080/newsapp/images/news10.jpg", "category1", "2022-12-14T21:00:00.000+00:00");
        data.add(n1);
        data.add(n2);
        data.add(n3);

        return data;
    }
}
