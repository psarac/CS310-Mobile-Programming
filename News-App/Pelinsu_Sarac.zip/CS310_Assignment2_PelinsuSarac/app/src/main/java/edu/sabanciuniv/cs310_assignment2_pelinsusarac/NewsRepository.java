package edu.sabanciuniv.cs310_assignment2_pelinsusarac;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Handler;
import android.os.Message;
import android.util.Log;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ExecutorService;

public class NewsRepository {

    public void getAllNews(ExecutorService srv, Handler uiHandler) {
        srv.execute(()-> {


            try {
                URL url = new URL("http://10.3.0.14:8080/newsapp/getall");
                HttpURLConnection conn = (HttpURLConnection) url.openConnection();

                BufferedReader reader = new BufferedReader(new InputStreamReader(conn.getInputStream()));

                StringBuilder buffer = new StringBuilder();
                String line = "";

                while((line=reader.readLine())!=null){

                    buffer.append(line);
                }


                JSONObject incomingJSON = new JSONObject(buffer.toString());
                //ServiceMessage<JSONArray> incomingMsg = new ServiceMessage<JSONArray>(incomingJSON.getInt("serviceMessageCode"),
                        //incomingJSON.getString("serviceMessageTest"), incomingJSON.getJSONArray("items"));
                JSONArray array = incomingJSON.getJSONArray("items");

                List<News> data = new ArrayList<>();

                //public News(int id, String title, String text, String imagePath, String categoryName, LocalDateTime date) {
                for (int i = 0; i < array.length(); i++) {
                    JSONObject current = array.getJSONObject(i);
                    News news = new News(
                            current.getInt("id"),
                            current.getString("title"),
                            current.getString("text"),
                            current.getString("image"),
                            current.getString("categoryName"),
                            current.getString("date")
                    );
                    data.add(news);
                }

                Message msg = new Message();
                msg.obj = data;
                uiHandler.sendMessage(msg);

            } catch (MalformedURLException e) {
                e.printStackTrace();
            } catch (IOException e) {
                e.printStackTrace();
            } catch (JSONException e) {
                e.printStackTrace();
            }
        });
    }

    public void getNewsByCategory (ExecutorService srv, Handler uiHandler, int categoryId) {

        srv.execute(()-> {

            try {
                URL url = new URL("http://10.3.0.14:8080/newsapp/getbycategoryid/" + String.valueOf(categoryId));
                HttpURLConnection conn = (HttpURLConnection) url.openConnection();

                BufferedReader reader = new BufferedReader(new InputStreamReader(conn.getInputStream()));

                StringBuilder buffer = new StringBuilder();
                String line = "";

                while((line=reader.readLine())!=null){

                    buffer.append(line);
                }

                //Log.v("DEV", buffer.toString());
                JSONObject incomingJSON = new JSONObject(buffer.toString());
                //ServiceMessage<JSONArray> incomingMsg = new ServiceMessage<JSONArray>(incomingJSON.getInt("serviceMessageCode"),
                        //incomingJSON.getString("serviceMessageText"), incomingJSON.getJSONArray("items"));

                JSONArray array = incomingJSON.getJSONArray("items");
                List<News> data = new ArrayList<>();

                for (int i = 0; i < array.length(); i++) {
                    JSONObject current = array.getJSONObject(i);
                    News news = new News(
                            current.getInt("id"),
                            current.getString("title"),
                            current.getString("text"),
                            current.getString("image"),
                            current.getString("categoryName"),
                            current.getString("date")
                    );
                    data.add(news);
                }

                Message msg = new Message();
                msg.obj = data;
                uiHandler.sendMessage(msg);

            } catch (MalformedURLException e) {
                e.printStackTrace();
            } catch (IOException e) {
                e.printStackTrace();
            } catch (JSONException e) {
                e.printStackTrace();
            }

        });
    }

    public void getNewsById (ExecutorService srv, Handler uiHandler, int id) {
        srv.execute(()-> {
            try {
                URL url = new URL("http://10.3.0.14:8080/newsapp/getnewsbyid/" + String.valueOf(id));
                HttpURLConnection conn = (HttpURLConnection) url.openConnection();

                BufferedReader reader = new BufferedReader(new InputStreamReader(conn.getInputStream()));

                StringBuilder buffer = new StringBuilder();
                String line = "";

                while((line=reader.readLine())!=null){

                    buffer.append(line);
                }

                JSONObject incomingJSON = new JSONObject(buffer.toString());
                //ServiceMessage<JSONArray> incomingMsg = new ServiceMessage<JSONArray>(incomingJSON.getInt("serviceMessageCode"),
                        //incomingJSON.getString("serviceMessageText"), incomingJSON.getJSONArray("items"));
                JSONArray array = incomingJSON.getJSONArray("items");

                JSONObject json = array.getJSONObject(0);
                News data = new News(json.getInt("id"), json.getString("title"), json.getString("text"),
                        json.getString("image"), json.getString("categoryName"), json.getString("date"));

                Message msg = new Message();
                msg.obj = data;
                uiHandler.sendMessage(msg);

            } catch (MalformedURLException e) {
                e.printStackTrace();
            } catch (IOException e) {
                e.printStackTrace();
            } catch (JSONException e) {
                e.printStackTrace();
            }
        });
    }

    public void downloadImage(ExecutorService srv, Handler uiHandler,String path){
        srv.execute(()->{
            try {
                URL url = new URL(path);
                HttpURLConnection conn = (HttpURLConnection)url.openConnection();

                Bitmap bitmap =  BitmapFactory.decodeStream(conn.getInputStream());

                Message msg = new Message();
                msg.obj = bitmap;
                uiHandler.sendMessage(msg);


            } catch (MalformedURLException e) {
                e.printStackTrace();
            } catch (IOException e) {
                e.printStackTrace();
            }

        });

    }
}
