package edu.sabanciuniv.cs310_assignment2_pelinsusarac;

import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Handler;
import android.os.Message;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ProgressBar;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.List;

public class TabFragment extends Fragment {

    //private String title;
    private int id;
    RecyclerView recNews;
    ProgressBar prg;

    Handler dataHandler = new Handler(new Handler.Callback() {
        @Override
        public boolean handleMessage(@NonNull Message msg) {
            List<News> data = (List<News>)msg.obj;
            NewsRecViewAdapter adp = new NewsRecViewAdapter(getActivity(),data);
            recNews.setAdapter(adp);
            recNews.setVisibility(View.VISIBLE);
            prg.setVisibility(View.INVISIBLE);

            return true;
        }
    });



    public TabFragment(int id) {

        //this.title = title;
        this.id = id;


    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View root = inflater.inflate(R.layout.fragment_tab, container, false);
        //TextView sampleTextView = root.findViewById(R.id.sampleTextView);
        //sampleTextView.setText(title);
        recNews = (RecyclerView) root.findViewById(R.id.recNews);
        prg = (ProgressBar) root.findViewById(R.id.progressBar2);
        recNews.setLayoutManager(new LinearLayoutManager(getActivity()));
        prg.setVisibility(View.VISIBLE);
        recNews.setVisibility(View.INVISIBLE);
        //recNews.setAdapter(null);

       NewsRepository repo = new NewsRepository();
       repo.getNewsByCategory(((NewsApplication)getActivity().getApplication()).srv, dataHandler, id);
        //repo.getNewsById(((NewsApplication)getActivity().getApplication()).srv, dataHandler, id);


        /*
        List<News> data = new ArrayList<>();
        News n1 = new News(1, "title1", "text1", "http://10.3.0.14:8080/newsapp/images/news10.jpg", "category1", "2022-12-14T21:00:00.000+00:00");
        News n2 = new News(2, "title2", "text1", "http://10.3.0.14:8080/newsapp/images/news10.jpg", "category1", "2022-12-14T21:00:00.000+00:00");
        News n3 = new News(3, "title3", "text1", "http://10.3.0.14:8080/newsapp/images/news10.jpg", "category1", "2022-12-14T21:00:00.000+00:00");
        data.add(n1);
        data.add(n2);
        data.add(n3);

         */

        /*
        News n = new News();
        List<News> data = n.returnData();

        NewsRecViewAdapter adp = new NewsRecViewAdapter(getActivity(),data);
        recNews.setAdapter(adp);

        recNews.setVisibility(View.VISIBLE);
        prg.setVisibility(View.INVISIBLE);
         */

        return root;
    }
}