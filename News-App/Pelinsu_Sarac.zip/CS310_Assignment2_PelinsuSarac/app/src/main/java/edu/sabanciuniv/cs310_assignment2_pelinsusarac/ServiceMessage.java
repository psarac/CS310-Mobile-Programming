package edu.sabanciuniv.cs310_assignment2_pelinsusarac;

public class ServiceMessage<T> {

    private int serviceMessageCode;
    private String serviceMessageTest;
    private T items;

    public ServiceMessage(int serviceMessageCode, String serviceMessageTest, T items) {
        this.serviceMessageCode = serviceMessageCode;
        this.serviceMessageTest = serviceMessageTest;
        this.items = items;
    }

    public ServiceMessage() {
    }

    public int getServiceMessageCode() {
        return serviceMessageCode;
    }

    public void setServiceMessageCode(int serviceMessageCode) {
        this.serviceMessageCode = serviceMessageCode;
    }

    public String getServiceMessageTest() {
        return serviceMessageTest;
    }

    public void setServiceMessageTest(String serviceMessageTest) {
        this.serviceMessageTest = serviceMessageTest;
    }

    public T getItems() {
        return items;
    }

    public void setItems(T items) {
        this.items = items;
    }
}
