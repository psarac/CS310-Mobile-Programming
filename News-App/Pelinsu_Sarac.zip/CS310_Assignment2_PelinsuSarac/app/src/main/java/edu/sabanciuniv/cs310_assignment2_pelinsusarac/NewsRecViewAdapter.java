package edu.sabanciuniv.cs310_assignment2_pelinsusarac;

import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.os.Handler;
import android.os.Message;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.recyclerview.widget.RecyclerView;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.concurrent.ExecutorService;

public class NewsRecViewAdapter extends RecyclerView.Adapter<NewsRecViewAdapter.NewsViewHolder>{

    private Context ctx;
    private List<News> data;

    public NewsRecViewAdapter(Context ctx, List<News> data) {
        this.ctx = ctx;
        this.data = data;
    }

    @NonNull
    @Override
    public NewsViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View root = LayoutInflater.from(ctx).inflate(R.layout.news_row_layout,parent,false);

        NewsViewHolder holder = new NewsViewHolder(root);
        holder.setIsRecyclable(false);
        return holder;
    }

    @Override
    public void onBindViewHolder(@NonNull NewsViewHolder holder, int position) {

        holder.title.setText(data.get(holder.getAdapterPosition()).getTitle());

        String strDate = data.get(holder.getAdapterPosition()).getDate();
        String needed = strDate.substring(0,10);
        //String[] arrOfStr = str.split("@", 2)
        String [] dateParts = needed.split("-");
        String newDate = dateParts[2] + "/" + dateParts[1] + "/" + dateParts[0];
        holder.date.setText(newDate);

        //OperatingSystemsApp app = (OperatingSystemsApp)((AppCompatActivity)ctx).getApplication();
        NewsApplication app = (NewsApplication)((AppCompatActivity)ctx).getApplication();

        holder.downloadImage(app.srv,data.get(holder.getAdapterPosition()).getImagePath());

        holder.row.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(ctx,NewsDetail.class);
                i.putExtra("id",data.get(holder.getAdapterPosition()).getId());
                //i.putExtra("category",categoryId);
                ctx.startActivity(i);


            }
        });



    }

    @Override
    public int getItemCount() {
        return data.size();
    }

    class NewsViewHolder extends RecyclerView.ViewHolder {

        TextView title;
        TextView date;
        ImageView imgList;
        boolean imageDownloaded;
        ConstraintLayout row;

        Handler imgHandler = new Handler(new Handler.Callback() {
            @Override
            public boolean handleMessage(@NonNull Message msg) {

                Bitmap img = (Bitmap)msg.obj;
                imgList.setImageBitmap(img);
                imageDownloaded = true;
                return true;
            }
        });

        public NewsViewHolder(@NonNull View itemView) {
            super(itemView);
            title = itemView.findViewById(R.id.titleView);
            date = itemView.findViewById(R.id.dateView);
            imgList = itemView.findViewById(R.id.imageView);
            row = itemView.findViewById(R.id.newrow);
        }

        public void downloadImage(ExecutorService srv, String path){

            if (!imageDownloaded){

                NewsRepository repo = new NewsRepository();
                repo.downloadImage(srv, imgHandler, path);

            }
        }
    }
}
